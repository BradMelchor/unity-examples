Welcome to MEMEHUNTER! The ultimate game that takes memes and merges them with a fun new experience.

Instructions:

To start the game you can hit play game, view on screen instructions or quit on the main menu.

While playing the game:

-Directional arrows and WAD keys control the character.
-Spacebar shoots out the illusive easter eggs in all video games.
-Pressing the "P" key can pause the game which gives options to resume, restart the level, or quit to the main menu.

Objective:

-You must never give up,or never let me down (If you decide to give up though you can always quit to the main menu). 
-Collect all of the MEME boxes to advance to the next level!!!!
-Make it through several levels to reach the end of the game. 
