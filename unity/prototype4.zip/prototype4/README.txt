Author: Brad Melchor
Date: 3/5/2021

Directions:

Holding the UP or Down arrow keys will move the ball forward or backwards, holding the left or right will turn the camera which the ball will follow to turn. 

Objective of the game is to knock the spawning enemies off the ledge, with or without a powerup. This will constantly spawn more enemies until the player falls off the edge.
Each wave will spawn one more enemy than last and will respawn a powerup. 